<?php ## Интерфейсы и абстрактные классы.
  interface I {
    public function F();
  }
  abstract class C implements I
  {
  }
?>