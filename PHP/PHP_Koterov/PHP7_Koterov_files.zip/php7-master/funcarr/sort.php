<?php ## Сортировка списков.
  $A = ["One", "Two", "Three", "Four"];
  sort($A);
  print_r($A);
  // Array([0]=>Four [1]=>One [2]=>Three [3]=>Two)
?>