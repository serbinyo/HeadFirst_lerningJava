<?php ## Проверочный скрипт Hello World.
  echo "Hello world!";
?>