<?php ## Класс cls
  class cls
  {
    public $var;
    public function __construct($var)
    {
      $this->var = $var;
    }
  }
?>