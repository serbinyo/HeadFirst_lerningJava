<?php ## Время изменения файла.
  $mtime = filemtime(__FILE__);
  echo "Последнее изменение страницы: ".date("Y-m-d H:i:s");
?>