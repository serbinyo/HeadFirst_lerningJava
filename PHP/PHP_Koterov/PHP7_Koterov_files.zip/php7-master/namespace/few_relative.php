<?php ## Относительные ссылки на элементы
  namespace PHP7;

  require_once 'few.php';
  $page = new classes\Page('Контакты', 'Содержимое страницы');
  functions\debug($page);
?>