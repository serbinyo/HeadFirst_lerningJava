<?php ## Использование потоков.
  require_once 'phar://phpinfo.phar/phpinfo.php';
