<?php ## Использование архива с бинарными данными.
  require_once('gallery.phar');