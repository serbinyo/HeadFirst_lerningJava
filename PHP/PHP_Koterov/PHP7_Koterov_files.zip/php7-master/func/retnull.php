<?php ## Неявный возврат NULL.
  function f() { }
  var_dump(f()); // NULL
?>
