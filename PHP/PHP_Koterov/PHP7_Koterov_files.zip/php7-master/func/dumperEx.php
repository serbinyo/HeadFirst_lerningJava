<?php ## Пример использования dumper().
  // Подключаем функцию dumper().
  require_once "dumper.php";
  dumper($GLOBALS);
?>