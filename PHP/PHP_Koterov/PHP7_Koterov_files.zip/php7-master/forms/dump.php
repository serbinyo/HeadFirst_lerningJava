<!DOCTYPE html>
<html lang="ru">
<head>
  <title>Выводит все глобальные переменные</title>
  <meta charset='utf-8'>
</head>
<body>
  <pre>
  <?php
    print_r($GLOBALS);
  ?>
  </pre>
</body>
</html>