<?php ## Использование DateTime.
  $date = new DateTime();
  echo $date->format("d-m-Y H:i:s"); // 14-11-2015 15:53:52
?>