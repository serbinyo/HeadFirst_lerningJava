<?php ## Отражение класса.
  $cls = new ReflectionClass('ReflectionException');
  echo "<pre>", $cls, "</pre>";
?>