<?php ## Содержимое $_SERVER
  echo "<pre>";
  print_r($_SERVER);
