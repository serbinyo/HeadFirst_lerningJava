<?php ## Отправка HTTP-заголовков после вывода данных.
  echo "hello world!";
  session_start();
?>